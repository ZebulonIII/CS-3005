#include <iostream>
#include "image_menu.h"

int main()
{
	int n = imageMenu(std::cin, std::cout);
	return n;
}
