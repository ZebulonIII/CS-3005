#include <iostream>
#include "image_menu.h"

int main()
{
	int n = assignment2(std::cin, std::cout);
	return n;
}